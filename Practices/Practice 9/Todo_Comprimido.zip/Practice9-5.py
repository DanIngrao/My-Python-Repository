import math

resultado = math.floor(89.665) #redondea abajo
print(resultado)
#89
resultado = math.ceil(89.665) #redondea arriba
print(resultado)
#90

resultado = math.log(100, 5) #a cuanto tengo que elevar 5 para llegar a 100
print(resultado)
#2.8613531161467867

resultado = math.tan(2565) #tangente
print(resultado)
#9.02100465179493